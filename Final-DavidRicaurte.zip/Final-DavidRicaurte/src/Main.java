import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		System.out.println("Bienvenidos al PokeMundo");
		System.out.println("Ingrese una opcion");
		ArrayList<LidesGimnasio> lista=new ArrayList<>();
		Scanner linea=new Scanner(System.in);
		while (true) {
			System.out.println("1.¿El profesor me pondra 5 en el final?");
			System.out.println("2.Mostrar los datos pedidos del final");
			System.out.println("3.Salir de esta groseria de final");
			int opcion=linea.nextInt();
			switch(opcion) {
			case 1:
				System.out.println("Escriba (1) en el caso que la nota sea igual 5 y (2) si la nota < 5");
				int respuesta=linea.nextInt();
				if(respuesta==1) {	
					System.out.println("Gracias mi perro se le quiere");
				}
				else
				{
					System.out.println("Me ilusionaste :(");
				}
				break;
			case 2:
				int aleatorio=0;
				aleatorio=(int)(Math.random()*101);
				int n=2;
				LidesGimnasio[] Lideres=new LidesGimnasio[n];
				for(int i=0;i<n;i++) {
					System.out.println("Ingrese el nombre del lider");	
					String nombre=linea.next();
					System.out.println("Ingrese el tipo de lider");
					String tipo=linea.next();
					System.out.println("Que tipo de clase");
					String clase=linea.next();
					System.out.println("Ingrese la cuidad");
					String cuidad=linea.next();
					String dulcesfavoritos[]= {"bombon","gomitas","frunas","nusita","bocadillo",
							"arequipe","brevas","cocadas"};
					System.out.println("Ingrese el % de fuerza");
					Long fuerza=linea.nextLong();
					int k=1;
					Pokemon[] Animal=new Pokemon[k];
					for(int j=0;j<k;j++) {
						System.out.println("Ingrese el nombre del pokemon");
						String nombrep=linea.next();
						String tipos[]= {"Bicho","fuego","planta","tierra","hielo","veneno","fantasma","aguga"};					
						String debilidades[]= {"volador","agua","bicho","hielo","acero","psiquico","siniestro","electrico"};
						System.out.println("Ingrese la cuidad de ataque");
						String cuidadAtaque=linea.next();
						System.out.println("Ingrese el % de ataque");
						Long ataque=linea.nextLong();
						System.out.println("Ingrese el % de defensa");
						Long defensa=linea.nextLong();
						String movimientos[]= {"beso dulce","encanto","luz lunar","mordisco","maldicion","atque arena"
								+"tornado","acido"};
						System.out.println("Ingrese el id de su gusto");
						int id=linea.nextInt();				
						Animal[j]=Pokemon(nombrep,tipos,debilidades,cuidadAtaque,ataque,defensa,movimientos,id);
					}

					Lideres[i]=LidesGimnasio (nombre,tipo,clase,cuidad,dulcesfavoritos,fuerza,Animal);
				}
			

				break;
			case 3:
				System.out.println("La buena monstruo, gracias por enseñarme a programar :)");
				return;
			default:
				System.out.println("Pongase serio hermano (Lea bien)");
				break;
			}


		}
	}

	private static LidesGimnasio LidesGimnasio(String nombre, String tipo, String clase, String cuidad,
			String[] dulcesfavoritos, Long fuerza, Pokemon[] animal) {
		// TODO Auto-generated method stub
		return null;
	}

	private static Pokemon Pokemon(String nombrep, String[] tipos, String[] debilidades, String cuidadAtaque,
			Long ataque, Long defensa, String[] movimientos, int id) {
		// TODO Auto-generated method stub
		return null;
	}
}










