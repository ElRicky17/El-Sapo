import java.util.Arrays;


public class Pokemon {

	int id =0;
	public String cuidadAtaque;
	public String nombrep;
	public String[] tipos;
	public String[] debilidades;
	public Long ataque;
	public Long defensa;
	public String[] movimientos;
	public int getId() {
		return id;
	}
	public Pokemon(String nombrep, String[] tipos,String[] debilidades,String cuidadAtaque, Long ataque,
			Long defensa, String[] movimientos,int id) {
		super();
		this.id = id;
		this.cuidadAtaque = cuidadAtaque;
		this.nombrep = nombrep;
		this.tipos = tipos;
		this.debilidades = debilidades;
		this.ataque = ataque;
		this.defensa = defensa;
		this.movimientos = movimientos;
	}


	public void setId(int id) {
		this.id = id;
	}
	public String getCuidadAtaque() {
		return cuidadAtaque;
	}
	public void setCuidadAtaque(String cuidadAtaque) {
		this.cuidadAtaque = cuidadAtaque;
	}
	public String getNombre() {
		return nombrep;
	}
	public void setNombre(String nombre) {
		this.nombrep = nombre;
	}
	public String[] getTipos() {
		return tipos;
	}
	public void setTipos(String[] tipos) {
		this.tipos = tipos;
	}
	public String[] getDebilidades() {
		return debilidades;
	}
	public void setDebilidades(String[] debilidades) {
		this.debilidades = debilidades;
	}
	public Long getAtaque() {
		return ataque;
	}
	public void setAtaque(Long ataque) {
		this.ataque = ataque;
	}
	public Long getDefensa() {
		return defensa;
	}
	public void setDefensa(Long defensa) {
		this.defensa = defensa;
	}
	public String[] getMovimientos() {
		return movimientos;
	}
	public void setMovimientos(String[] movimientos) {
		this.movimientos = movimientos;
	}
	@Override
	public String toString() {
		return "Pokemon [id=" + id + ", cuidadAtaque=" + cuidadAtaque + ", nombre=" + nombrep + ", tipos="
				+ Arrays.toString(tipos) + ", debilidades=" + Arrays.toString(debilidades) + ", ataque=" + ataque
				+ ", defensa=" + defensa + ", movimientos=" + Arrays.toString(movimientos) + "]";
	}
	public void mostrarDebelidades() {
		for(String debilidad:debilidades) {
			System.out.println(debilidad);
		}
	}
	public String mostrarDatos() {
		return "El nombre es"+nombrep+",tipo"+tipos+"con ataque"+ataque+"y denfesa"+defensa;
	   //NOMBRE, TIPO, ATQUE, DEFENSA
	}
}



