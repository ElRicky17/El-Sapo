import java.util.Arrays;

public class LidesGimnasio {
	public String tipo;
	public String[] dulcesfavoritos;
	public Pokemon[] pokemon;
	public String cuidad;
	public Long fuerza;
	public String nombre;
	public String clase;

	public LidesGimnasio(String nombre, String tipo,String clase,String cuidad, String[] dulcesfavoritos,Long fuerza,
			Pokemon[] pokemon) {
		super();
		this.clase = clase;
		this.tipo = tipo;
		this.dulcesfavoritos = dulcesfavoritos;
		this.pokemon = pokemon;
		this.cuidad = cuidad;
		this.fuerza = fuerza;
		this.nombre = nombre;
	}

	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getClase() {
		return clase;
	}
	public void setClase(String clase) {
		this.clase = clase;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public String[] getDulcesfavoritos() {
		return dulcesfavoritos;
	}
	public void setDulcesfavoritos(String[] dulcesfavoritos) {
		this.dulcesfavoritos = dulcesfavoritos;
	}

	public Pokemon[] getPokemon() {
		return pokemon;
	}

	public void setPokemon(Pokemon[] pokemon) {
		this.pokemon = pokemon;
	}

	public String getCuidad() {
		return cuidad;
	}
	public void setCuidad(String cuidad) {
		this.cuidad = cuidad;
	}
	public Long getFuerza() {
		return fuerza;
	}
	public void setFuerza(Long fuerza) {
		this.fuerza = fuerza;
	}
	@Override
	public String toString() {
		return "LidesGimnasio [clase=" + clase + ", tipo=" + tipo + ", dulcesfavoritos="
				+ Arrays.toString(dulcesfavoritos) + ", pokemon=" + Arrays.toString(pokemon) + ", cuidad=" + cuidad
				+ ", fuerza=" + fuerza + ", nombre=" + nombre + "]";
	}
	public void mostrarPokemon() {
		for(Pokemon Pokemo:pokemon) {
			System.out.println(Pokemo);

		}
	}
	public String mostrarDatos() {
		return "El nombre es"+nombre+",tipo"+tipo;
	
	}
}



